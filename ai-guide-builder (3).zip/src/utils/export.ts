import JSZip from "jszip";
import { GuideData } from "../types";

// Dynamic client-side aspect ratio cropping for high-fidelity exports
function cropImageToRatio(dataUrl: string, ratio: string): Promise<string> {
  return new Promise((resolve) => {
    if (!dataUrl || ratio === "original") {
      resolve(dataUrl);
      return;
    }

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        resolve(dataUrl);
        return;
      }

      const cw = img.width;
      const ch = img.height;
      let sw = cw;
      let sh = ch;
      let sx = 0;
      let sy = 0;

      const ratioMap: Record<string, number> = {
        "1:1": 1,
        "4:3": 4 / 3,
        "16:9": 16 / 9,
        "9:16": 9 / 16
      };
      const targetRatio = ratioMap[ratio] || 16 / 9;
      const imgRatio = cw / ch;

      if (imgRatio > targetRatio) {
        sw = ch * targetRatio;
        sx = (cw - sw) / 2;
      } else {
        sh = cw / targetRatio;
        sy = (ch - sh) / 2;
      }

      canvas.width = sw;
      canvas.height = sh;
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      resolve(canvas.toDataURL("image/png"));
    };
    img.onerror = () => {
      resolve(dataUrl);
    };
    img.src = dataUrl;
  });
}

export async function exportZipBundle(guideData: GuideData, screenshotRatio: string) {
  const zip = new JSZip();

  // Create guide.md with rich document styling
  let md = `# ${guideData.guide_title}\n\n`;
  md += `> **Target Audience:** ${guideData.target_audience}\n\n`;
  md += `## Executive Summary\n${guideData.summary}\n\n`;
  md += `---\n\n`;
  md += `## Step-by-Step Training Manual\n\n`;

  // We loop through steps, crop images to selected ratio dynamically, and append them
  for (const step of guideData.steps) {
    const filename = `step_${step.step_number}.png`;
    
    md += `### Step ${step.step_number}: ${step.title}\n\n`;
    md += `- **Timestamp:** ⏱️ ${step.timestamp}\n`;
    md += `- **Instructional Action:** ${step.action}\n`;
    md += `- **Visual Cue / Screen Feedback:** *${step.visual_cue}*\n\n`;
    
    if (step.screenshotDataUrl) {
      md += `![Step ${step.step_number} Screenshot](./${filename})\n\n`;
      
      // Dynamic on-the-fly cropping to ensure exported ZIP images respect the current crop ratio selector
      const croppedDataUrl = await cropImageToRatio(step.screenshotDataUrl, screenshotRatio);
      const base64Data = croppedDataUrl.split(",")[1];
      zip.file(filename, base64Data, { base64: true });
    } else {
      md += `*(No screenshot captured for this action step)*\n\n`;
    }
    
    md += `---\n\n`;
  }

  zip.file("guide.md", md);

  // Generate and download the zip bundle
  const content = await zip.generateAsync({ type: "blob" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(content);
  link.download = `${guideData.guide_title.toLowerCase().replace(/[^a-z0-9]+/g, "_")}_archive.zip`;
  link.click();
}

export function exportHtmlDocument(guideData: GuideData) {
  let stepsHtml = '';
  let outlineHtml = '';
  
  guideData.steps.forEach(step => {
    const stepId = `step-${step.step_number}`;
    const imageTag = step.screenshotDataUrl
      ? `<div class="step-image-container">
          <img src="${step.screenshotDataUrl}" alt="Step ${step.step_number} screenshot" />
         </div>`
      : `<div class="step-no-image">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-camera"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
          <span>No Screenshot Captured</span>
         </div>`;

    outlineHtml += `
      <a href="#${stepId}" class="sidebar-link" id="outline-link-${step.step_number}">
        <span class="link-num">${step.step_number}</span>
        <span class="link-text">${escapeHtml(step.title)}</span>
      </a>`;

    stepsHtml += `
      <section id="${stepId}" class="doc-step-section">
        <div class="step-header">
          <div class="step-badge">Step ${step.step_number}</div>
          <span class="step-timestamp">⏱️ ${step.timestamp}</span>
        </div>
        
        <h3 class="step-title">${escapeHtml(step.title)}</h3>
        
        <div class="step-body-grid">
          <div class="step-media-pane">
            ${imageTag}
          </div>
          
          <div class="step-content-pane">
            <div class="section-block">
              <span class="block-label">Instructional Action</span>
              <p class="block-text action-text">${escapeHtml(step.action)}</p>
            </div>
            
            <div class="section-block">
              <span class="block-label">On-Screen Feedback / Visual Cue</span>
              <p class="block-text cue-text">${escapeHtml(step.visual_cue)}</p>
            </div>
          </div>
        </div>
      </section>`;
  });

  const docStr = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(guideData.guide_title)}</title>
  <style>
    :root {
      --primary: #4f46e5;
      --primary-hover: #4338ca;
      --text-main: #0f172a;
      --text-muted: #334155;
      --text-label: #64748b;
      --bg-page: #f8fafc;
      --bg-sidebar: #ffffff;
      --bg-content: #ffffff;
      --border: #e2e8f0;
      --radius: 8px;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background-color: var(--bg-page);
      color: var(--text-main);
      line-height: 1.5;
      display: flex;
      min-height: 100vh;
      overflow-x: hidden;
    }

    /* Layout Wrapper */
    .app-container {
      display: flex;
      width: 100%;
      min-height: 100vh;
      position: relative;
    }

    /* Sidebar Table of Contents */
    .sidebar {
      width: 280px;
      background-color: var(--bg-sidebar);
      border-right: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      position: sticky;
      top: 0;
      height: 100vh;
      z-index: 100;
      transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
      flex-shrink: 0;
    }

    .sidebar.collapsed {
      width: 0;
      transform: translateX(-280px);
      overflow: hidden;
      border-right-width: 0;
    }

    .sidebar-header {
      padding: 20px;
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .sidebar-title {
      font-size: 0.82rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-label);
    }

    .btn-toggle-sidebar {
      background: none;
      border: none;
      color: var(--text-label);
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.2s;
    }

    .btn-toggle-sidebar:hover {
      background-color: #f1f5f9;
      color: var(--text-main);
    }

    .sidebar-menu {
      flex: 1;
      overflow-y: auto;
      padding: 12px 8px;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .sidebar-link {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 12px;
      border-radius: 6px;
      text-decoration: none;
      color: var(--text-muted);
      font-size: 0.85rem;
      font-weight: 500;
      transition: all 0.15s ease;
      border-left: 3px solid transparent;
    }

    .sidebar-link:hover {
      background-color: #f1f5f9;
      color: var(--text-main);
    }

    .sidebar-link.active {
      background-color: #eff6ff;
      color: var(--primary);
      border-left-color: var(--primary);
      font-weight: 600;
    }

    .link-num {
      width: 20px;
      height: 20px;
      background-color: #f1f5f9;
      color: var(--text-label);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      font-weight: 700;
      flex-shrink: 0;
    }

    .sidebar-link.active .link-num {
      background-color: #dbeafe;
      color: var(--primary);
    }

    .link-text {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* Main Content Pane */
    .main-pane {
      flex: 1;
      min-width: 0;
      background-color: var(--bg-page);
      display: flex;
      flex-direction: column;
    }

    /* Global Nav Bar */
    .navbar {
      height: 56px;
      background-color: #ffffff;
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      padding: 0 24px;
      gap: 12px;
      position: sticky;
      top: 0;
      z-index: 90;
    }

    .navbar-brand {
      font-size: 0.9rem;
      font-weight: 700;
      color: var(--text-main);
    }

    .btn-sidebar-trigger {
      background-color: #f1f5f9;
      border: 1px solid var(--border);
      color: var(--text-muted);
      cursor: pointer;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 0.8rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.2s;
    }

    .btn-sidebar-trigger:hover {
      background-color: #e2e8f0;
      color: var(--text-main);
    }

    .btn-print {
      margin-left: auto;
      background-color: var(--primary);
      color: #ffffff;
      border: none;
      padding: 6px 14px;
      border-radius: 6px;
      font-size: 0.8rem;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: background-color 0.2s;
    }

    .btn-print:hover {
      background-color: var(--primary-hover);
    }

    /* Document View */
    .doc-view {
      padding: 32px 40px;
      max-width: 1000px;
      width: 100%;
      margin: 0 auto;
    }

    /* Document Header - Professional, Tight */
    .doc-header {
      background-color: #ffffff;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 24px 32px;
      margin-bottom: 24px;
    }

    .doc-meta-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      color: var(--primary);
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 12px;
    }

    .doc-title {
      font-size: 1.6rem;
      font-weight: 800;
      letter-spacing: -0.02em;
      color: var(--text-main);
      line-height: 1.2;
      margin-bottom: 12px;
    }

    .doc-summary {
      font-size: 0.95rem;
      color: var(--text-muted);
      margin-bottom: 16px;
      line-height: 1.5;
    }

    .doc-meta-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 16px;
      padding-top: 14px;
      border-top: 1px solid var(--border);
    }

    .meta-item {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .meta-label {
      font-size: 0.7rem;
      font-weight: 700;
      color: var(--text-label);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .meta-value {
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--text-muted);
    }

    /* Flowing continuous steps list - No chunky cards, tight dividers */
    .doc-flow {
      background-color: #ffffff;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      overflow: hidden;
    }

    .doc-step-section {
      padding: 24px 32px;
      border-bottom: 1px solid var(--border);
      scroll-margin-top: 72px; /* Smooth scroll offset */
    }

    .doc-step-section:last-child {
      border-bottom: none;
    }

    .step-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }

    .step-badge {
      font-size: 0.75rem;
      font-weight: 700;
      background-color: #f1f5f9;
      color: var(--text-label);
      padding: 3px 8px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.02em;
    }

    .step-timestamp {
      font-size: 0.75rem;
      font-weight: 700;
      color: var(--primary);
    }

    .step-title {
      font-size: 1.15rem;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 14px;
      letter-spacing: -0.01em;
    }

    /* Grid layout for step body */
    .step-body-grid {
      display: grid;
      grid-template-columns: 280px 1fr;
      gap: 20px;
      align-items: start;
    }

    /* Checkerboard image container */
    .step-media-pane {
      width: 100%;
    }

    .step-image-container {
      width: 100%;
      aspect-ratio: 16 / 10;
      border-radius: 6px;
      border: 1px solid var(--border);
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      
      /* Transparency Checkerboard background instead of Solid Black */
      background-image: linear-gradient(45deg, #f8fafc 25%, transparent 25%),
                        linear-gradient(-45deg, #f8fafc 25%, transparent 25%),
                        linear-gradient(45deg, transparent 75%, #f8fafc 75%),
                        linear-gradient(-45deg, transparent 75%, #f8fafc 75%);
      background-size: 12px 12px;
      background-position: 0 0, 0 6px, 6px -6px, -6px 0px;
      background-color: #e2e8f0;
    }

    .step-image-container img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }

    .step-no-image {
      width: 100%;
      aspect-ratio: 16 / 10;
      background-color: #f8fafc;
      border: 1px dashed var(--border);
      border-radius: 6px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 6px;
      color: var(--text-label);
      font-size: 0.8rem;
    }

    .step-content-pane {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .section-block {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .block-label {
      font-size: 0.7rem;
      font-weight: 700;
      color: var(--text-label);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .block-text {
      font-size: 0.85rem;
      color: var(--text-muted);
    }

    .action-text {
      font-weight: 600;
      color: #1e293b;
    }

    .cue-text {
      font-style: italic;
      color: #475569;
    }

    /* Footer */
    .footer {
      text-align: center;
      margin-top: 32px;
      color: var(--text-label);
      font-size: 0.75rem;
      padding-bottom: 24px;
    }

    /* Mobile Edge to Edge Layout */
    @media (max-width: 768px) {
      .app-container {
        flex-direction: column;
      }
      
      .sidebar {
        position: fixed;
        left: 0;
        bottom: 0;
        top: 56px;
        height: calc(100vh - 56px);
        width: 100%;
        max-width: 280px;
        transform: translateX(-280px);
        box-shadow: 4px 0 12px rgba(0,0,0,0.15);
      }
      
      .sidebar.active-mobile {
        transform: translateX(0);
      }

      .doc-view {
        padding: 0; /* Tight, edge to edge */
      }

      .doc-header {
        border-radius: 0;
        border-left: none;
        border-right: none;
        padding: 16px;
        margin-bottom: 12px;
      }

      .doc-flow {
        border-radius: 0;
        border-left: none;
        border-right: none;
      }

      .doc-step-section {
        padding: 16px;
      }

      .step-body-grid {
        grid-template-columns: 1fr;
        gap: 12px;
      }
    }

    /* Print Styles */
    @media print {
      .sidebar, .navbar {
        display: none !important;
      }
      .app-container {
        display: block;
      }
      .main-pane {
        display: block;
        background-color: #ffffff;
      }
      .doc-view {
        padding: 0;
        max-width: 100%;
      }
      .doc-header {
        border: none;
        padding: 0 0 20px 0;
        border-bottom: 2px solid #000000;
        margin-bottom: 30px;
      }
      .doc-flow {
        border: none;
      }
      .doc-step-section {
        page-break-inside: avoid;
        border-bottom: 1px solid #e2e8f0;
        padding: 24px 0;
      }
    }
  </style>
</head>
<body>
  <div class="app-container">
    
    <!-- Collapsible Sidebar Table of Contents -->
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-header">
        <span class="sidebar-title">Outline Index</span>
        <button class="btn-toggle-sidebar" onclick="toggleSidebar()" title="Collapse Outline">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        </button>
      </div>
      <nav class="sidebar-menu">
        ${outlineHtml}
      </nav>
    </aside>

    <!-- Main View Panel -->
    <main class="main-pane">
      <header class="navbar">
        <button class="btn-sidebar-trigger" onclick="toggleSidebar()">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/></svg>
          <span id="btn-toggle-text">Toggle Outline</span>
        </button>
        <span class="navbar-brand">User Training Manual</span>
        <button class="btn-print" onclick="window.print()">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/></svg>
          <span>Save to PDF</span>
        </button>
      </header>

      <div class="doc-view">
        <header class="doc-header">
          <div class="doc-meta-badge">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle;"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5z"/><path d="M6 6h10M6 10h10"/></svg>
            <span>Interactive Guide</span>
          </div>
          <h1 class="doc-title">${escapeHtml(guideData.guide_title)}</h1>
          <p class="doc-summary">${escapeHtml(guideData.summary)}</p>

          <div class="doc-meta-grid">
            <div class="meta-item">
              <span class="meta-label">Target Audience</span>
              <span class="meta-value">${escapeHtml(guideData.target_audience)}</span>
            </div>
            <div class="meta-item">
              <span class="meta-label">Manual Length</span>
              <span class="meta-value">${guideData.steps.length} Actions</span>
            </div>
            <div class="meta-item">
              <span class="meta-label">Compiled Date</span>
              <span class="meta-value">${new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
          </div>
        </header>

        <div class="doc-flow">
          ${stepsHtml}
        </div>

        <footer class="footer">
          Generated via <strong>AI Guide Builder Pro</strong>
        </footer>
      </div>
    </main>
  </div>

  <script>
    // Sidebar Collapsing Logic
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      const textSpan = document.getElementById('btn-toggle-text');
      
      if (window.innerWidth <= 768) {
        sidebar.classList.toggle('active-mobile');
      } else {
        sidebar.classList.toggle('collapsed');
        if (sidebar.classList.contains('collapsed')) {
          textSpan.textContent = 'Expand Outline';
        } else {
          textSpan.textContent = 'Collapse Outline';
        }
      }
    }

    // Active link highlighting on scroll
    const sections = document.querySelectorAll('.doc-step-section');
    const navLinks = document.querySelectorAll('.sidebar-link');

    window.addEventListener('scroll', () => {
      let current = '';
      sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (pageYOffset >= (sectionTop - 120)) {
          current = section.getAttribute('id');
        }
      });

      navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#' + current) {
          link.classList.add('active');
          link.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      });
    });

    // Close mobile sidebar on link click
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
          document.getElementById('sidebar').classList.remove('active-mobile');
        }
      });
    });
  </script>
</body>
</html>`;

  const blob = new Blob([docStr], { type: "text/html" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = guideData.guide_title.toLowerCase().replace(/[^a-z0-9]+/g, "_") + "_guide.html";
  link.click();
}

function escapeHtml(str: string): string {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
